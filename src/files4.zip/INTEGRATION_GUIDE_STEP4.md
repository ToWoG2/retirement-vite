# STEP 4 INTEGRATION GUIDE - Enhanced Liquidity Strategy

## 📋 Overview

Step 4 implements a sophisticated **three-tier liquidity framework** based on UBS Wealth Way:

- **Tier I**: Immediate access (3 months expenses) - Emergency cash
- **Tier II**: Near-term reserve (15 months) - Planned expenses  
- **Tier III**: Strategic reserve (24 months) - Medium-term needs

Plus dynamic refilling based on market conditions and SBLOC (Securities-Backed Line of Credit) analysis.

---

## 📦 New Files Created

1. **liquidityStrategy.js** - Core logic and calculations (450 lines)
2. **EnhancedLiquidityStrategy.jsx** - Visual component (500 lines)
3. **INTEGRATION_GUIDE_STEP4.md** - This file

---

## 🚀 OPTION 1: Add as New Tab (Recommended)

### Step 1: Copy Files

```bash
cd ~/Desktop/Claude/projects/RetirementPlanner/retirement-planner/src

# Copy the new files (they're in your outputs folder)
cp /path/to/liquidityStrategy.js ./
cp /path/to/EnhancedLiquidityStrategy.jsx ./
```

### Step 2: Update RetirementPlannerWithTabs.jsx

Open `RetirementPlannerWithTabs.jsx` and add:

**At the top (imports):**
```javascript
import EnhancedLiquidityStrategy from './EnhancedLiquidityStrategy';
```

**In the tabs array (around line 18):**
```javascript
const tabs = [
  { 
    id: 'calculator', 
    label: { 
      en: 'Retirement Calculator', 
      de: 'Rentenrechner', 
      fr: 'Calculateur de Retraite' 
    }, 
    icon: '📊' 
  },
  { 
    id: 'asset-allocation', 
    label: { 
      en: 'Asset Allocation', 
      de: 'Vermögensallokation', 
      fr: 'Allocation d\'Actifs' 
    }, 
    icon: '📈' 
  },
  { 
    id: 'liquidity',           // NEW TAB
    label: { 
      en: 'Liquidity Strategy', 
      de: 'Liquiditätsstrategie', 
      fr: 'Stratégie de Liquidité' 
    }, 
    icon: '💰' 
  },
  { 
    id: 'legal-tax', 
    label: { 
      en: 'Legal & Tax Framework', 
      de: 'Rechts- & Steuerrahmen', 
      fr: 'Cadre Juridique & Fiscal' 
    }, 
    icon: '⚖️' 
  }
];
```

**In the tab content section (around line 90, after Asset Allocation tab):**
```javascript
{/* LIQUIDITY STRATEGY TAB */}
{activeTab === 'liquidity' && (
  <div className="animate-fadeIn">
    <EnhancedLiquidityStrategy 
      annualExpenses={60000}  // Replace with actual value from calculator
      currentLiquidity={{
        tierI: 15000,
        tierII: 50000,
        tierIII: 80000
      }}
      longevityBucketValue={500000}  // Replace with actual value
      currency={sharedState.currency}
      language={sharedState.language}
    />
  </div>
)}
```

### Step 3: Test It

```bash
npm run dev
```

You should now see **4 tabs**: Calculator | Asset Allocation | Liquidity Strategy | Legal & Tax

---

## 🔗 OPTION 2: Integrate Into Calculator (Advanced)

If you want the liquidity strategy embedded in the calculator results instead of a separate tab:

### Modify RetirementPlannerComplete.jsx

**At the top:**
```javascript
import EnhancedLiquidityStrategy from './EnhancedLiquidityStrategy';
```

**In the results section (after the bucket displays):**
```javascript
{/* Add Liquidity Strategy Section */}
<div className="mt-8">
  <EnhancedLiquidityStrategy 
    annualExpenses={inputs.retirementExpenses}
    currentLiquidity={{
      tierI: liquidityBucketCash * 0.2,   // 20% in Tier I
      tierII: liquidityBucketCash * 0.35,  // 35% in Tier II
      tierIII: liquidityBucketCash * 0.45  // 45% in Tier III
    }}
    longevityBucketValue={longevityBucketTotal}
    currency={inputs.currency}
    language={inputs.language}
  />
</div>
```

---

## 💡 Understanding the Component

### Key Features

1. **Three-Tier Visualization**
   - Shows current vs target for each tier
   - Progress bars and deficit/surplus calculations
   - Color-coded for easy understanding

2. **Market Condition Detection**
   - Bull Market: Refill aggressively
   - Normal Market: Systematic refilling
   - Bear Market: Preserve investments, live off liquidity
   - Volatile Market: Selective refilling

3. **Dynamic Refilling Strategy**
   - Calculates what needs to be refilled
   - Prioritizes based on market conditions
   - Shows if it's feasible from longevity bucket

4. **Securities-Backed Line of Credit (SBLOC)**
   - Calculates borrowing capacity (70% LTV)
   - Shows safe utilization (50% of max)
   - Lists advantages and risks
   - Monthly interest estimates

5. **Emergency Guidelines**
   - Sudden expenses (under 10k, 50k, 100k, over 100k)
   - Job loss scenarios
   - Health crises
   - Market crashes

### Props Explained

```javascript
<EnhancedLiquidityStrategy 
  annualExpenses={60000}          // Annual retirement expenses
  currentLiquidity={{              // Current holdings in each tier
    tierI: 15000,                  // Immediate access (checking, savings)
    tierII: 50000,                 // Near-term (short bonds, CDs)
    tierIII: 80000                 // Strategic (balanced funds)
  }}
  longevityBucketValue={500000}   // Total longevity bucket for refilling
  currency="USD"                  // Display currency
  language="en"                   // Interface language
/>
```

### Data Structure (liquidityStrategy.js)

**Main exports:**
- `liquidityTiers` - Definition of three tiers
- `refillingRules` - Market-based refilling strategies
- `calculateLiquidityNeeds()` - Calculates target for each tier
- `determineMarketCondition()` - Analyzes market state
- `calculateRefillingSchedule()` - Builds refilling plan
- `securitiesBackedLoan` - SBLOC calculations and info
- `emergencyGuidelines` - Scenario-based guidance

---

## 🎨 Customization Options

### Change Tier Targets

In `liquidityStrategy.js`, modify the multipliers:

```javascript
export const calculateLiquidityNeeds = (annualExpenses, multipliers = null) => {
  const defaults = {
    tierI: 0.25,   // 3 months (change to 0.5 for 6 months)
    tierII: 1.25,  // 15 months (change to 1.0 for 12 months)
    tierIII: 2.0   // 24 months (change to 3.0 for 36 months)
  };
  // ...
};
```

### Adjust Market Thresholds

```javascript
// In determineMarketCondition()
if (percentFromHigh < -20) {        // Change -20 to -15 for more sensitive
  return 'bearMarket';
}

if (percentFromHigh > -5) {         // Change -5 to -10 for stricter
  return 'bullMarket';
}
```

### Modify SBLOC Parameters

```javascript
typical: {
  loanToValue: 0.70,     // Change to 0.60 for more conservative
  interestRate: 5.5,     // Update with current rates
  minPortfolio: 100000,  // Adjust minimum
  // ...
}
```

---

## 📊 Visual Examples

### What You'll See

```
┌─────────────────────────────────────────────────────────┐
│  Enhanced Liquidity Strategy                            │
│  Three-Tier Framework for Optimal Cash Management      │
└─────────────────────────────────────────────────────────┘

┌──────────────┬──────────────┬──────────────┐
│  Tier I      │  Tier II     │  Tier III    │
│  Immediate   │  Near-Term   │  Strategic   │
│              │              │              │
│  Current:    │  Current:    │  Current:    │
│  $15,000     │  $50,000     │  $80,000     │
│              │              │              │
│  Target:     │  Target:     │  Target:     │
│  $15,000 ✓   │  $75,000     │  $120,000    │
│              │              │              │
│  [Progress]  │  [Progress]  │  [Progress]  │
│  ████████    │  ████░░░░    │  ███░░░░░    │
│  100%        │  67%         │  67%         │
└──────────────┴──────────────┴──────────────┘

Market Condition: Bull Market 🟢
Strategy: Aggressive refilling from longevity bucket

Refilling Needed:
  Tier II: $25,000 (Priority 1)
  Tier III: $40,000 (Priority 2)
  Total: $65,000 ✓ Feasible (13% of longevity bucket)

Securities-Backed Line of Credit:
  Maximum Loan: $350,000
  Safe Utilization: $175,000
  Monthly Interest: ~$1,604
```

---

## ✅ Testing Checklist

After integration:

- [ ] Liquidity tab appears (if using Option 1)
- [ ] Three tiers display with correct colors (green, blue, purple)
- [ ] Current vs Target calculations are accurate
- [ ] Progress bars show correct percentages
- [ ] Market condition displays and changes color
- [ ] Refilling schedule appears when there are deficits
- [ ] SBLOC section expands/collapses
- [ ] Emergency guidelines expand/collapses
- [ ] Multi-language works (EN/DE/FR)
- [ ] Currency symbols display correctly
- [ ] No console errors

---

## 🔧 Troubleshooting

### Issue: "Cannot find module liquidityStrategy"
**Solution:** Make sure both files are in the `src/` directory

### Issue: Component doesn't display
**Solution:** Check browser console for errors. Verify all imports are correct.

### Issue: Values showing as NaN or undefined
**Solution:** Ensure you're passing valid numbers to props, not strings

### Issue: Styling looks wrong
**Solution:** Make sure Tailwind CSS is installed and configured

---

## 📈 What's Next?

**Step 5: Longevity Bucket Refinement**
- Country-specific life expectancy with health factors
- Annuity analysis and optimization
- Sequence of returns risk visualization
- Spending flexibility rules

**Step 6: Income Sources Integration**
- Social Security optimizer
- Pension integration
- Multiple income streams
- Part-time work scenarios

---

## 💼 Real-World Usage Example

```javascript
// Example: 65-year-old retiree with $2M portfolio
<EnhancedLiquidityStrategy 
  annualExpenses={80000}           // $80k/year spending
  currentLiquidity={{
    tierI: 20000,                  // $20k in checking/savings
    tierII: 60000,                 // $60k in short-term bonds
    tierIII: 100000                // $100k in balanced funds
  }}
  longevityBucketValue={1500000}  // $1.5M in growth portfolio
  currency="USD"
  language="en"
/>

// Calculates:
// - Target Tier I: $20k (3 months) ✓
// - Target Tier II: $100k (15 months) - needs $40k
// - Target Tier III: $160k (24 months) - needs $60k
// - Market condition analysis
// - Refilling strategy based on conditions
// - SBLOC capacity: $1.05M max loan
```

---

## 📚 Key Concepts Explained

### Why Three Tiers?

1. **Tier I (3 months)**: True emergencies only. Ultra-safe, instant access.
2. **Tier II (15 months)**: Planned expenses and near-term needs. Low-risk.
3. **Tier III (24 months)**: Strategic buffer. Moderate risk acceptable.

**Total: ~3.5 years of expenses** in liquid/near-liquid assets before touching long-term investments.

### Dynamic Refilling

Traditional advice: "Keep 3-6 months expenses in cash"

**UBS Wealth Way approach**: Adjust based on market:
- **Bull market**: Refill aggressively (lock in gains)
- **Bear market**: Live off liquidity longer (avoid selling at losses)
- **Volatile**: Be selective, maintain core tiers only

### SBLOC as Safety Valve

Instead of selling investments during a bear market:
1. Use SBLOC to borrow against portfolio
2. Maintain investment exposure for recovery
3. Repay loan when market recovers
4. Avoid locking in losses + tax hit

**Example:**
- Need $50k during 30% market decline
- Option A: Sell $50k of investments (lock in 30% loss = need to sell $71k pre-loss)
- Option B: Borrow $50k via SBLOC at 5.5%, wait for recovery, repay

---

## 🎯 Success Metrics

After implementing Step 4, you should be able to:

✅ Visualize liquidity across three distinct tiers
✅ See current allocation vs optimal targets
✅ Get market-aware refilling recommendations
✅ Understand SBLOC as an emergency tool
✅ Access scenario-based emergency guidelines
✅ Make informed decisions about cash management

---

## 🆘 Need Help?

1. **Component not showing**: Check browser console (F12)
2. **Wrong calculations**: Verify props are numbers, not strings
3. **Styling issues**: Ensure Tailwind CSS is working (test with other components)
4. **Import errors**: Check file paths and names match exactly

---

## 📝 Notes

- This is a **planning tool**, not financial advice
- Users should adapt tier targets to their risk tolerance
- SBLOC terms vary by institution - always check current rates
- Market condition detection is simplified - real analysis is more complex
- Encourage users to consult financial advisors for personalized strategies

---

**Created**: February 2026  
**Version**: 1.0  
**Part of**: UBS Wealth Way Retirement Planner Enhancement Project
