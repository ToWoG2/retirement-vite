# STEP 5 INTEGRATION GUIDE - Longevity Bucket Refinement

## 📋 Overview

Step 5 implements advanced longevity planning features:

- **Life Expectancy Calculator**: Country-specific with health and lifestyle adjustments
- **Annuity Analysis**: 4 types (SPIA, DIA, FIA, QLAC) with comparison tools
- **Sequence of Returns Risk**: Visualize and mitigate early bear market risk
- **Dynamic Spending Rules**: Guardrails, constant percentage, floor/ceiling strategies

---

## 📦 New Files Created

1. **longevityData.js** (500 lines) - Life expectancy, health factors, sequence risk
2. **annuityAnalysis.js** (400 lines) - Annuity types, calculations, comparisons
3. **LongevityBucketRefinement.jsx** (650 lines) - Comprehensive visual component
4. **INTEGRATION_GUIDE_STEP5.md** - This file

---

## 🚀 Quick Start - Add as New Tab

### Step 1: Copy Files

```bash
cd ~/Desktop/Claude/projects/RetirementPlanner/retirement-planner/src

# Copy the three new files from outputs folder
```

### Step 2: Update RetirementPlannerWithTabs.jsx

**Add import at top:**
```javascript
import LongevityBucketRefinement from './LongevityBucketRefinement';
```

**Add to tabs array (around line 40):**
```javascript
{ 
  id: 'longevity',
  label: { 
    en: 'Longevity Planning', 
    de: 'Langlebigkeitsplanung', 
    fr: 'Planification de Longévité' 
  }, 
  icon: '⏳' 
}
```

**Add tab content (around line 115):**
```javascript
{/* LONGEVITY PLANNING TAB */}
{activeTab === 'longevity' && (
  <div className="animate-fadeIn">
    <LongevityBucketRefinement 
      country={sharedState.country}
      gender="male"  // Get from calculator if available
      currentAge={65}  // Get from calculator if available
      portfolioValue={1000000}  // Get from calculator
      annualExpenses={60000}  // Get from calculator
      guaranteedIncome={20000}  // Social Security + pension
      currency={sharedState.currency}
      language={sharedState.language}
    />
  </div>
)}
```

### Step 3: Test It

```bash
npm run dev
```

You should now see **5 tabs**:
📊 Calculator | 📈 Asset Allocation | 💰 Liquidity | ⏳ **Longevity** | ⚖️ Legal & Tax

---

## 🎯 Component Features

### 1. Life Expectancy Calculator

**Country Data** (7 countries):
- Luxembourg, Switzerland, France, UK, Portugal, Germany, US
- Base life expectancy by gender
- Healthcare quality ratings
- Source references

**Health Status Adjustments:**
- Excellent: +3.5 years
- Good: +1.5 years
- Average: 0 years
- Poor: -3.0 years

**Lifestyle Factors** (cumulative):
- Smoking: -5.0 (current) to +0.5 (never)
- Exercise: -2.0 (sedentary) to +2.5 (vigorous)
- BMI: -5.0 (severely obese) to +1.0 (normal)
- Alcohol: -3.0 (heavy) to +0.5 (none/light)
- Stress: -3.0 (chronic) to +1.0 (low)
- Sleep: -1.5 (poor) to +1.0 (excellent)
- Social Connections: -2.0 (isolated) to +1.5 (strong)

**Example Output:**
```
Base Life Expectancy: 81.9 years (Swiss male)
Health Adjustment: +1.5 (good health)
Lifestyle Adjustment: +3.0 (healthy habits)
Adjusted Life Expectancy: 86.4 years
Remaining Years: 21.4 years (from age 65)

Planning Horizons:
  Conservative: 91.4 years (plan for +5 years)
  Moderate: 86.4 years (plan to life expectancy)
  Aggressive: 83.4 years (plan for -3 years)
```

### 2. Annuity Analysis

**Four Annuity Types:**

**A) SPIA (Single Premium Immediate Annuity)**
- Lump sum → immediate lifetime income
- Typical payout: 5.8% at 65, 8.2% at 75
- Best for: covering essential expenses, age 70+

**B) DIA (Deferred Income Annuity / Longevity Annuity)**
- Buy now, income starts later (e.g., age 80-85)
- Typical payout: 18% if buy at 65/start at 80
- Best for: protecting against living "too long"

**C) FIA (Fixed Index Annuity)**
- Principal protected, returns linked to index
- Upside capped (~6%), downside protected (0% floor)
- Best for: market exposure with protection

**D) QLAC (Qualified Longevity Annuity Contract)**
- Special DIA for retirement accounts
- Reduces RMDs, defers taxes
- $200k maximum, must start by age 85

**Annuity vs Portfolio Comparison:**
```
$200,000 Premium | Age 65 Male

ANNUITY OPTION:
Annual Income: $11,600 (5.8% payout)
Guaranteed: ✓ Yes
Market Risk: None
Assets Remaining: $0

PORTFOLIO OPTION (4% Rule):
Annual Income: $8,000 (4% withdrawal)
Guaranteed: ✗ No
Market Risk: Yes
Assets Remaining: $200,000

Recommendation: Annuity provides $3,600/year MORE income
Consider hybrid: annuity for essentials, portfolio for discretionary
```

**Optimal Annuitization Strategy:**
```
Conservative: 35% of portfolio → covers 50-75% of essentials
Moderate: 20% of portfolio → covers 30-50% of essentials
Aggressive: 10% of portfolio (DIA only) → minimal annuity

Example (Moderate):
Portfolio: $1,000,000
Essential Expenses: $60,000/year
Guaranteed Income: $20,000 (Social Security)
Income Gap: $40,000

Suggested Annuity: $200,000 (20% of portfolio)
Projected Income: $12,000/year (6% payout)
Total Guaranteed: $32,000 (53% of essentials ✓)
Remaining Portfolio: $800,000 (for discretionary + legacy)
```

### 3. Sequence of Returns Risk

**The Problem:**
Market crashes early in retirement are devastating. A 30% drop in year 1-3 can cripple a portfolio permanently.

**Three Scenarios:**

**Early Bear (First 5 years):**
- Risk Level: HIGH 🔴
- Impact: Severe - portfolio may not recover
- Mitigations:
  - Larger liquidity bucket (5+ years)
  - Reduce withdrawals by 10-20%
  - Part-time work or delay retirement
  - Increase bond allocation temporarily

**Mid-Retirement Bear (10-15 years in):**
- Risk Level: MEDIUM 🟡
- Impact: Moderate - stressed but recoverable
- Mitigations:
  - Maintain 3-tier liquidity
  - Reduce discretionary spending
  - Consider SBLOC vs selling
  - Delay major expenses

**Late Bear (20+ years in):**
- Risk Level: LOW 🟢
- Impact: Low - less time for compound losses
- Mitigations:
  - Maintain current strategy
  - Focus on legacy planning
  - Consider reducing equity exposure

**Your Sequence Risk Analysis:**
```
Portfolio: $1,000,000
Years in Retirement: 0 (just retired)
Withdrawal Rate: 4%

Potential Loss (if early bear): $120,000
Recovery Time: 12 years
Priority: CRITICAL - Build larger liquidity buffer

Recommendation:
Increase liquidity bucket from 3.5 years to 5+ years
This protects against selling during first critical years
```

### 4. Dynamic Spending Rules

**Guardrails Strategy:**
```
Initial Portfolio: $1,000,000
Initial Spending: $40,000/year

Upper Guardrail: +20% ($1,200,000)
  → Increase spending by 10% to $44,000

Within Range: $850,000 - $1,200,000
  → Maintain $40,000

Lower Guardrail: -15% ($850,000)
  → Decrease spending by 10% to $36,000
```

**Constant Percentage (4% Rule):**
- Withdraw 4% of current portfolio each year
- Pro: Never run out
- Con: Variable income

**Floor & Ceiling:**
- Set minimum (e.g., 80% of desired)
- Set maximum (e.g., 120% of desired)
- Prevents extreme swings

**Dynamic Withdrawal:**
Adjusts based on:
- Age (increase as you age)
- Market condition (decrease in bear markets)
- Remaining years (increase if running out of time)

---

## 💡 Props Explained

```javascript
<LongevityBucketRefinement 
  country="LU"                // For life expectancy lookup
  gender="male"               // 'male' or 'female'
  currentAge={65}             // Current age
  portfolioValue={1000000}    // Total investable assets
  annualExpenses={60000}      // Annual spending need
  guaranteedIncome={20000}    // Social Security + pension
  currency="USD"              // Display currency
  language="en"               // Interface language
/>
```

---

## 📊 Data Structures

### longevityData.js Exports:

```javascript
import {
  calculateLifeExpectancy,  // Main calculation function
  healthFactors,            // Health status definitions
  lifestyleFactors,         // Lifestyle adjustments
  sequenceOfReturnsRisk,    // Sequence risk scenarios
  spendingFlexibility       // Dynamic spending rules
} from './longevityData';

// Example usage:
const result = calculateLifeExpectancy(
  'CH',      // Switzerland
  'male',    // Male
  65,        // Age 65
  'good',    // Good health
  {
    smoking: 'never',
    exercise: 'moderate_3to4',
    bmi: 'normal'
  }
);

console.log(result);
// {
//   baseLifeExpectancy: 81.9,
//   adjustedLifeExpectancy: 86.4,
//   remainingYears: 21.4,
//   planningHorizons: {...}
// }
```

### annuityAnalysis.js Exports:

```javascript
import {
  annuityTypes,             // 4 annuity type definitions
  calculateAnnuityPayout,   // Calculate income from premium
  annuityVsPortfolio,       // Compare annuity vs self-management
  annuitizationStrategy     // Optimal % to annuitize
} from './annuityAnalysis';

// Example:
const payout = calculateAnnuityPayout(
  200000,  // $200k premium
  65,      // Age 65
  'male',  // Male
  'spia'   // Immediate annuity
);

console.log(payout);
// {
//   annualPayout: 11600,
//   monthlyPayout: 967,
//   payoutRate: 5.8,
//   breakEven: 17.2  // Years to recover premium
// }
```

---

## 🎨 Customization

### Add More Countries:

Edit `longevityData.js`:

```javascript
export const lifeExpectancyData = {
  // ... existing countries
  
  IT: {
    country: 'Italy',
    male: { base: 81.3, healthy: 83.1, excellent: 85.5 },
    female: { base: 85.6, healthy: 87.2, excellent: 89.6 },
    source: 'ISTAT 2024',
    healthcareQuality: 8.7,
    notes: 'Mediterranean diet benefits'
  }
};
```

### Adjust Annuity Payout Rates:

Edit `annuityAnalysis.js`:

```javascript
typicalPayoutRate: {
  age65_male: 0.060,    // Update to 6.0% from 5.8%
  age65_female: 0.055,  // Update to 5.5% from 5.3%
  // ...
}
```

### Modify Spending Rules:

Edit `longevityData.js`:

```javascript
guardrails: {
  thresholds: {
    upperGuardrail: 1.25,  // Change to +25% instead of +20%
    lowerGuardrail: 0.80,  // Change to -20% instead of -15%
  }
}
```

---

## ✅ Testing Checklist

After integration:

- [ ] Longevity tab appears and loads
- [ ] Life expectancy calculator shows results
- [ ] Health status dropdown works
- [ ] Lifestyle selectors update calculations
- [ ] Adjusted life expectancy updates correctly
- [ ] Annuity slider adjusts premium and income
- [ ] Annuity vs Portfolio comparison displays
- [ ] Optimal strategy calculates correctly
- [ ] Annuity details expand/collapse
- [ ] Sequence risk section expands/collapse
- [ ] Three risk scenarios display (early/mid/late)
- [ ] Spending rules section expands/collapse
- [ ] Multi-language works (EN/DE/FR)
- [ ] Currency symbols display correctly
- [ ] No console errors

---

## 🔧 Troubleshooting

### Issue: Life expectancy shows "null"
**Solution:** Check that country code matches longevityData.js (LU, CH, FR, UK, PT, DE, US)

### Issue: Annuity calculations seem wrong
**Solution:** Verify age is between 60-85 and premium is reasonable ($50k-$500k)

### Issue: Component doesn't display
**Solution:** Check browser console. Ensure recharts is installed: `npm install recharts`

### Issue: Styling broken
**Solution:** Verify Tailwind CSS is configured and working

---

## 📈 Integration Status

✅ **Step 1**: Country legal/tax data  
✅ **Step 2**: Legal & Tax Framework tab  
✅ **Step 3**: Risk Profile & Asset Allocation  
✅ **Step 4**: Enhanced Liquidity Strategy  
✅ **Step 5**: Longevity Bucket Refinement ← **YOU ARE HERE**  
⏭️ **Step 6**: Income Sources Integration  
⏭️ **Step 7**: Enhanced Visualizations  
⏭️ **Step 8**: Scenario Persistence  

---

## 🎯 Real-World Example

```javascript
// 67-year-old Swiss female, excellent health
<LongevityBucketRefinement 
  country="CH"
  gender="female"
  currentAge={67}
  portfolioValue={1500000}
  annualExpenses={70000}
  guaranteedIncome={30000}  // Swiss pension + AHV
  currency="CHF"
  language="de"
/>

// Results:
// Base LE: 85.7 years
// Excellent health: +3.5
// Healthy lifestyle: +4.0
// Adjusted LE: 93.2 years
// Remaining: 26.2 years

// Planning: Conservative to age 98
// Annuity suggestion: CHF 300,000 (20%)
// → CHF 18,000/year income
// → 69% essential expenses covered
```

---

## 📚 Key Concepts

### Life Expectancy vs Planning Horizon

**Life Expectancy**: Average age at death (50% die before, 50% after)
**Planning Horizon**: Age to plan for (typically LE + 5 years)

Why +5? Because:
- 25% chance of living past LE + 4 years
- 10% chance of living past LE + 10 years
- Better to have too much than run out

### Annuity Break-Even

If you pay $200k for $12k/year annuity:
- Break-even: 16.7 years (age 82 if bought at 65)
- If you die at 75: Lost $80k
- If you live to 95: Gained $160k ($360k received - $200k paid)

**Longevity insurance**: Worth it if worried about living "too long"

### Sequence Risk Reality

Example: $1M portfolio, $40k withdrawals

**Scenario A - Good sequence:**
Year 1: +10% → $1.06M (after withdrawal)
Year 2: +8% → $1.105M
Year 3: -20% → $844k
Final after 30 years: $1.2M

**Scenario B - Bad sequence:**
Year 1: -20% → $760k (after withdrawal)
Year 2: +8% → $781k
Year 3: +10% → $819k
Final after 30 years: $0 (ran out at year 24!)

**Same average return, wildly different outcomes!**

---

## 💼 Professional Usage Tips

1. **Start with life expectancy** - Sets the foundation for all planning
2. **Use conservative planning horizon** - Better safe than sorry
3. **Consider annuity for essentials** - Guarantee basic lifestyle
4. **Keep portfolio for discretionary** - Flexibility and legacy
5. **Review annually** - Health and markets change
6. **Don't over-annuitize** - Keep some flexibility
7. **Sequence risk is real** - Protect first 5-10 years aggressively

---

**Created**: February 2026  
**Version**: 1.0  
**Part of**: UBS Wealth Way Retirement Planner Enhancement Project
